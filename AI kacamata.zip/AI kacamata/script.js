const URL = "./model/";

let model, webcam, labelContainer, maxPredictions;

async function init() {
    try {
        console.log("Memulai aplikasi...");

        const modelURL = URL + "model.json";
        const metadataURL = URL + "metadata.json";

        console.log("Memuat model...");

        model = await tmImage.load(modelURL, metadataURL);

        console.log("Model berhasil dimuat");

        maxPredictions = model.getTotalClasses();

        const flip = true;
        webcam = new tmImage.Webcam(400, 300, flip);

        await webcam.setup();
        await webcam.play();

        window.requestAnimationFrame(loop);

        document.getElementById("webcam-container").appendChild(webcam.canvas);

        labelContainer = document.getElementById("label-container");
        labelContainer.innerHTML = "";

        for (let i = 0; i < maxPredictions; i++) {
            labelContainer.appendChild(document.createElement("div"));
        }

    } catch (err) {
        console.error(err);
        alert("Terjadi error: " + err.message);
    }
}

async function loop() {
    webcam.update();
    await predict();
    window.requestAnimationFrame(loop);
}

async function predict() {
    const prediction = await model.predict(webcam.canvas);

    let terbaik = prediction.reduce((a, b) =>
        a.probability > b.probability ? a : b
    );

    const persen = (terbaik.probability * 100).toFixed(2);

    document.getElementById("result").innerHTML = "👓 " + terbaik.className;
    document.getElementById("score").innerHTML = persen + "%";
    document.getElementById("bar").style.width = persen + "%";

    for (let i = 0; i < prediction.length; i++) {
        labelContainer.childNodes[i].innerHTML =
            "<b>" + prediction[i].className + "</b><br>" +
            (prediction[i].probability * 100).toFixed(2) + "%";
    }
}